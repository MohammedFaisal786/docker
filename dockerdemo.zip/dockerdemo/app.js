// const express = require('express')

// const app = express();

// app.get('/', (req, res)=>{
// res.send('Hello World')
// })


// app.listen(3000, ()=>{
//  console.log('server is created')
// })
// const app = require('express')

// const app = express();

// app.get('/', (req, res)=>{
// res.send('Hello World')
// })


// app.listen(3000, ()=>{
//  console.log('server is created')
// })
// ovj-wbrk-shx
const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('Hello World');
});


app.listen(3000, () => {
    console.log('Server is created');
});
